#!/bin/bash
# Prosty benchmark CLI
