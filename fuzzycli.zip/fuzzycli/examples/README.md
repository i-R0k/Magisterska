# Jak uruchomić przykład tipper
