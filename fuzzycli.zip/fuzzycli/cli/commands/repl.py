# Implementacja komendy: `mamdani repl ...`
