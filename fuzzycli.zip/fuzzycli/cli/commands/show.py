# Implementacja komendy: `mamdani show ...`
