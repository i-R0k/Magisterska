## Opis użycia CLI (drukowany w --help)
