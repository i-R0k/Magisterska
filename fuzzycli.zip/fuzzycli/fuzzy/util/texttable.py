# Proste formatowanie tabel w konsoli
