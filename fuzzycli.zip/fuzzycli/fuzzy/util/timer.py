# Mierzenie czasu, proste profile
