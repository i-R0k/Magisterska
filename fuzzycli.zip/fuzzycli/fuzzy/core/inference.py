# Kroki wnioskowania (FIT/FATI) bez I/O
