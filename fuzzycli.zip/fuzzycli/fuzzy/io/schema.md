## SPEC języka .fz (opis formalny/BNF)
