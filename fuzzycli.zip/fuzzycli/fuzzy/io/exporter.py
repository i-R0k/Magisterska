# Eksport wyników (csv/json), zapis modelu
