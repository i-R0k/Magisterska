# Testy metod defuzyfikacji
