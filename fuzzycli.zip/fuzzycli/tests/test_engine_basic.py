# Testy podstawowego działania silnika
