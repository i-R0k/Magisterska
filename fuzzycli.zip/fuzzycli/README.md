# Instrukcja instalacji i użycia CLI
